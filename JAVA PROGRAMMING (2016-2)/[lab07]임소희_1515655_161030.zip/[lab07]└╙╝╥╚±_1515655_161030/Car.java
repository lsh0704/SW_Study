public class Car extends Vehicle implements Movable{
	double distance;
	double liter;
	
	public void setDistance(double distance) {
		this.distance = distance;
	}
	public void setLiter(double liter) {
		this.liter = liter;
	}
	
	public double getKilosPerLiter() {
		//����(���ʹ� �̵��Ÿ�)�� ��ȯ
		return distance/liter;
	}
	
	public void speedUp(int amount){
		speed+=amount;
	}
	public void speedDown(int amount){
		speed-=amount;
	}
	
	public void turnLeft() {
		System.out.println("��ȸ��");
	}
	public void turnRight() {
		System.out.println("��ȸ��");
	}
}
