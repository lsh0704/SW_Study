
public class CarTest {

	public static void main(String[] args) {
		Car c1 = new Car();
		c1.setDistance(100);
		c1.setLiter(20);
		System.out.println("c1 ����: "+c1.getKilosPerLiter());
		for (int i=0; i<5; i++)
			c1.speedUp(10);
		c1.printSpeed();
		Car c2 = new Car();
		c2.setDistance(200);
		c2.setLiter(30);
		System.out.println("c2 ����: "+c2.getKilosPerLiter());
		for (int i=0; i<5; i++)
			c2.speedUp(10);
		c2.speedDown(20);
		c2.printSpeed();
	}
}
