import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class FontTest extends JFrame implements ActionListener, ItemListener{
	JTextField t1 = new JTextField("20",18); /*p6*/
	JTextField t2 = new JTextField("Hello Java!",18);
	int fo=2; //font
	int fs=0; int fs2=0;//font style
	int fsize=20; //font size
	int z=0; //�ʱ�ȭ �ѹ��� �ϱ����� ���
	private JRadioButton f1, f2, f3; //����, ����, �ü�
	JCheckBox[] buttons = new JCheckBox[2]; //BOLD, ITALIC
	String[] style = { "BOLD", "ITALIC" };
	String text = "";
	
	public FontTest() {
	this.setPreferredSize(new Dimension(300, 300));
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setTitle("Font ����");
	setLayout(new BorderLayout());
	
	JPanel p1 = new JPanel(); // Label
	JPanel p2 = new JPanel(); // ������ , p2=p4+p5+p6
	JPanel p3= new JPanel(); // �������
	JPanel p4 = new JPanel(); //radio button
	JPanel p5 = new JPanel(); //check box
	JPanel p6 = new JPanel(); //text Field
	
	p1.setLayout(new BoxLayout(p1, BoxLayout.Y_AXIS));/*p1*/
	JLabel l1 = new JLabel("   Font ����"); 
	JLabel l2 = new JLabel("   Style ����");
	JLabel l3 = new JLabel("   Size ����");
	JLabel l4 = new JLabel("   Text ����");
	JLabel nul = new JLabel("	"); //����
	JLabel nul2 = new JLabel("	"); //����
	JLabel nul3 = new JLabel("	"); //����
	JLabel nul4 = new JLabel("	"); //����
	p1.add(nul); p1.add(l1); p1.add(nul2); 
	p1.add(l2);	p1.add(nul3);
	p1.add(l3);	p1.add(nul4);
	p1.add(l4);		
		
	f1 = new JRadioButton("����", true); /*p4*/
	f1.addActionListener(this);
	f2 = new JRadioButton("����");
	f2.addActionListener(this);
	f3 = new JRadioButton("�ü�");	
	f3.addActionListener(this);
	ButtonGroup type = new ButtonGroup(); //�׷칭��
	type.add(f1);	type.add(f2);	type.add(f3);
	
	p4.add(f1);	p4.add(f2);	p4.add(f3);
	
	t1.addActionListener(this); //�ؽ�Ʈ��Ʈ�� �׼Ǹ����� ����, /*p6*/
	t2.addActionListener(this);
		
	for (int i=0; i<2; i++) { /*p5*/
		buttons[i] = new JCheckBox(style[i]); //üũ�ڽ�����
		buttons[i].addItemListener(this);
		}	
	p5.add(buttons[0]);	p5.add(buttons[1]); 
	
	JLabel nul5 = new JLabel("	"); //����
	p6.add(t1);	p6.add(nul5); p6.add(t2);
	p6.setLayout(new BoxLayout(p6, BoxLayout.Y_AXIS));
	p2.add(p4);	p2.add(p5);	p2.add(p6); //p2=p4+p5+p6	
	
	add(p1, BorderLayout.WEST);
	add(p2, BorderLayout.CENTER);
	add(p3, BorderLayout.SOUTH);
	
	draw d = new draw();
	Border result = BorderFactory.createTitledBorder("Font ���� ���"); /*p3*/
		d.setBorder(result);
		add(d, BorderLayout.SOUTH);
		d.setPreferredSize(new Dimension(100, 90)); 
		pack();
		setVisible(true);	
	}

	class draw extends JPanel{ 
		protected void paintComponent (Graphics g) {
			super.paintComponent(g);	
			Font font = new Font("����", Font.PLAIN, fsize);
			if (z<1) {				
				g.setFont(font);
				g.drawString("Hello Java!", 85, 50); //�ʱⰪ
			}

			if (fo==1 && fs==0 && fs2==0)
				font = new Font("����", Font.PLAIN, fsize);
			if (fo==1 && fs==1 && fs2==0)
				font = new Font("����", Font.BOLD, fsize);
			if (fo==1 && fs==0 && fs2==1)
				font = new Font("����", Font.ITALIC, fsize); 
			if (fo==1 && fs==1 && fs2==1)
				font = new Font("����", Font.BOLD+Font.ITALIC, fsize); 

			if (fo==2 && fs==0 && fs2==0)
				font = new Font("����", Font.PLAIN, fsize);
			if (fo==2 && fs==1 && fs2==0)
				font = new Font("����", Font.BOLD, fsize);
			if (fo==2 && fs==0 && fs2==1)
				font = new Font("����", Font.ITALIC, fsize); 
			if (fo==2 && fs==1 && fs2==1)
				font = new Font("����", Font.BOLD+Font.ITALIC, fsize); 

			if (fo==3 && fs==0 && fs2==0)
				font = new Font("�ü�", Font.PLAIN, fsize);
			if (fo==3 && fs==1 && fs2==0)
				font = new Font("�ü�", Font.BOLD, fsize);
			if (fo==3 && fs==0 && fs2==1)
				font = new Font("�ü�", Font.ITALIC, fsize); 
			if (fo==3 && fs==1 && fs2==1)
				font = new Font("�ü�", Font.BOLD+Font.ITALIC, fsize); 
			g.setFont(font);
			g.drawString(text, 85, 50);	
			repaint(); 
		}	
	}
	
	public void actionPerformed(ActionEvent e) {
		fsize = Integer.parseInt(t1.getText());
		text = t2.getText();
		if (f1.isSelected()) {//����
			fo=1;	z=1;
			}
		if (f2.isSelected()) {//����
			fo=2;	z=1;
		}
		if (f3.isSelected()) {//�ü�
			fo=3;	z=1;
		}	
		if (e.getSource() == t1 || e.getSource() == t2) {
			fsize = Integer.parseInt(t1.getText());
			text = t2.getText(); 	z=1;
		}
	}
	
	public void itemStateChanged (ItemEvent e) {
		Object source = e.getItemSelectable();
		fsize = Integer.parseInt(t1.getText());
		text = t2.getText();
		if (source == buttons[0]) {
			if (e.getStateChange() == ItemEvent.SELECTED)
				fs=1;	z=1;
			if (e.getStateChange() == ItemEvent.DESELECTED) 
				fs=0;	z=1;	
			}
		if (source == buttons[1]) {
			if (e.getStateChange() == ItemEvent.SELECTED)
				fs2=1;	z=1;
			if (e.getStateChange() == ItemEvent.DESELECTED) 
				fs2=0;	z=1;	
			}	
	}
							
	public static void main(String[] args) {
		FontTest f = new FontTest();
	}
}



