import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;


public class MouseEventTest extends JFrame 
{
	private JButton button1;	private JButton button2;
	private JButton button3;	private JButton button4;
	private JButton button5;	private JButton button6;
	ButtonListener blistener = new ButtonListener();
	int a,b,c,d; //��ǥ��
	int n=0, m=0; //n=�÷�����,m=��������
	
	public MouseEventTest() {
		this.setPreferredSize(new Dimension(600, 600));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("MouseEvent Test");
		setLayout(new BorderLayout());
		
		JPanel figure = new JPanel(); // ��,�簢��,Ÿ�� �г� (WEST)
		JPanel color = new JPanel(); // Red,Blue,Green �г� (EAST)
		panel p = new panel(); //�׸� �׸��� �� (CENTER)
		
		figure.setLayout(new GridLayout(3,1));
		button1 = new JButton("��");
		button2 = new JButton("�簢��");
		button3 = new JButton("Ÿ��");
		button1.addActionListener(blistener);
		button2.addActionListener(blistener);
		button3.addActionListener(blistener);		
		figure.add(button1);	figure.add(button2);	figure.add(button3);
		
		color.setLayout(new GridLayout(3,1));
		button4 = new JButton("Red");
		button5 = new JButton("Blue");
		button6 = new JButton("Green");
		button4.addActionListener(blistener);
		button5.addActionListener(blistener);
		button6.addActionListener(blistener);
		color.add(button4);	color.add(button5);	color.add(button6);
		
		add(figure, BorderLayout.WEST);
		add(p, BorderLayout.CENTER);
		add(color, BorderLayout.EAST);
		
		p.addMouseListener(p);
		p.addMouseMotionListener(p);
		pack();
		this.setVisible(true);
	}
	
	class panel extends JPanel implements MouseListener, MouseMotionListener{ 
		protected void paintComponent(Graphics g) { //�׸� �׸��� �� (CENTER)
			super.paintComponent(g);
			if (n==0)	g.setColor(Color.black); //�ʱⰪ
			if (n==1)	g.setColor(Color.red);
			if (n==2)	g.setColor(Color.blue);
			if (n==3)	g.setColor(Color.green);
			if (m==0)	g.drawLine(a,b,c,d); //�ʱⰪ
			if (m==1)	g.drawLine(a,b,c,d);
			if (m==2)	g.drawRect(a,b,c,d);
			if (m==3)	g.drawOval(a,b,c,d);		
		}
		public void mousePressed(MouseEvent e) {
			a=e.getX();	b=e.getY();
		}
		public void mouseReleased(MouseEvent e) {
			c=e.getX();	d=e.getY();
		}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
		public void mouseClicked(MouseEvent e) {}
		public void mouseDragged(MouseEvent e) {
			c=e.getX();	d=e.getY(); repaint();
		}
		public void mouseMoved(MouseEvent e) {}
	}

	private class ButtonListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (e.getSource() == button1) 
				m=1;
			if (e.getSource() == button2) 
				m=2;
			if (e.getSource() == button3) 
				m=3;
			if (e.getSource() == button4) 
				n=1;
			if (e.getSource() == button5) 
				n=2;
			if (e.getSource() == button6) 
				n=3;
			}			
		}

	public static void main(String[] args) {
		MouseEventTest d = new MouseEventTest();
	}
}


