import java.util.Scanner;

public class MathTest {

	public static void main(String[] args) {
		double pi=Math.PI;
		
		Scanner scan = new Scanner(System.in);
		System.out.print("������ �Է�: ");
		int radius = scan.nextInt();
		
		System.out.println("���� �ѷ�: "+(2*pi*radius)+
				", ���� ����: "+(pi*radius*radius));
		System.out.println("");
		
		System.out.print("a: ");
		int a = scan.nextInt();
		System.out.print("b: ");
		int b = scan.nextInt();
		
		double phtha = Math.hypot(a, b); // ������(a^2+b^2)
		System.out.println("c: "+phtha);
	}

}
