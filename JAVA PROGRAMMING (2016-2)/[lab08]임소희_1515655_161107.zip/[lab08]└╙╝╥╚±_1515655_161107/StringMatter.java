
public class StringMatter {

	public static void main(String[] args) {
		String s1 = "Java Korea";
		String s2 = new String("Java Korea");
		String s3 = s1;

		System.out.println(s1.equals(s2)); //true
		System.out.println(s1.replace('a', 'A')); //JAvA KoreA
		System.out.println(s2.toUpperCase()); //JAVA KOREA
		System.out.println(s2.length()); //10
		System.out.println(s1.lastIndexOf('a')); //9
		System.out.println(s2.substring(5)); //
		System.out.println(s1.substring(0, 4)); //Java
		System.out.println(s1.compareTo(s2)); //0
		System.out.println(s1.compareTo(s3)); //0
		System.out.println(s1.startsWith("java")); //false
	}
}
