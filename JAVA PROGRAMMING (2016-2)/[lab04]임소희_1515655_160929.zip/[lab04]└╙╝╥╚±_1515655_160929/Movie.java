
public class Movie {
	private String title;
	private String director;
	private String actors;
	private int year;
	int total;
}
