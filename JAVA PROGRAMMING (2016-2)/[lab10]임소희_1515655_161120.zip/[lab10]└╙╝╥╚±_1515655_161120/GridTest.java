import java.awt.*;
import javax.swing.*;

public class GridTest extends JFrame{
	public GridTest() {
		this.setPreferredSize(new Dimension(600, 300));
		setSize(600, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("GUI TEST");
		setLayout(new BorderLayout()); //frame
		
		JPanel panel1; //�� ����
		panel1 = new JPanel();
		panel1.setLayout(new FlowLayout(FlowLayout.CENTER)); //panel1	
		JLabel label = new JLabel("�л� ���� �Է�");
		panel1.add(label);
		
		
		JPanel panel2; // �� && ǥ
		panel2 = new JPanel();
		panel2.setLayout(new GridLayout(5,4)); //panel2
		JLabel label1 = new JLabel("�� ��");
		panel2.add(label1);
		JLabel label2 = new JLabel("�� ��");
		panel2.add(label2);
		JLabel label3 = new JLabel("�� ��");
		panel2.add(label3);
		JLabel label4 = new JLabel("����ó");
		panel2.add(label4);
		
		for (int i=0; i<16; i++)
			makeTextEdit(panel2);
		
		
		JPanel panel3; //�߰� ��� ��ư
		panel3 = new JPanel();
		panel3.setLayout(new FlowLayout(FlowLayout.CENTER)); //panel3
		panel3.add(new JButton("�߰�"));
		panel3.add(new JButton("���"));
		
		add(panel1, BorderLayout.NORTH);
		add(panel2, BorderLayout.CENTER);
		add(panel3, BorderLayout.SOUTH);
		
		pack();
		setVisible(true);		
	}
	

	private void makeTextEdit(JPanel panel) {
		JTextField t = new JTextField();
		t.setAlignmentX(Component.CENTER_ALIGNMENT);
		t.setEditable(true);
		panel.add(t);
	}
	public static void main(String[] args) {
		GridTest g = new GridTest();
	}

}

