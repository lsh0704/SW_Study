import java.awt.*;
import javax.swing.*;

class GuiTest extends JFrame {
	public GuiTest() {
		
		this.setPreferredSize(new Dimension(300, 200));
		setSize(300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("GUI TEST");
		
		JPanel panel1; 
		panel1 = new JPanel();	
		
		JLabel label1 = new JLabel("�� ��");
		panel1.add(label1);
		JTextField t = new JTextField(20);
		panel1.add(t);
		
		JLabel label2 = new JLabel("�� ��");
		panel1.add(label2);
		JTextField t1 = new JTextField(20);
		panel1.add(t1);
		
		JLabel label3 = new JLabel("�� ��");
		panel1.add(label3);
		JTextField t2 = new JTextField(20);
		
		t2.setText("��ǻ�Ͱ��� ����");
		t2.setEditable(false);
		panel1.add(t2);
		
		JLabel label4 = new JLabel("����ó");
		panel1.add(label4);
		JTextField t3 = new JTextField(20);
		panel1.add(t3);
		
		panel1.add(new JButton("Ȯ��"));
		panel1.add(new JButton("���"));
		
		add(panel1);
		pack();
		setVisible(true);		
	}
	
	public static void main(String[] args) {
		GuiTest g = new GuiTest();
	}

}
