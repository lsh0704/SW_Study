import java.awt.*;
import javax.swing.*;

public class JPanelTest extends JFrame{
	public JPanelTest() {
		this.setPreferredSize(new Dimension(500, 215));
		setSize(500, 215);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("JPanelTest");
		setLayout(new BorderLayout()); //frame
		
		JPanel panel1; //�� ����
		panel1 = new JPanel();
		panel1.setLayout(new FlowLayout(FlowLayout.CENTER)); //panel1	
		JLabel label = new JLabel("�� �� ��");
		panel1.add(label);
		
		JPanel panel2; //�� && �Է�ĭ && ���� (p2 = p5+p6+p7)
		panel2 = new JPanel();
		
		JPanel panel5 = new JPanel(); //�� p5
		panel5.setLayout(new BoxLayout(panel5, BoxLayout.Y_AXIS));
		JLabel label1 = new JLabel("�� ��");
		panel5.add(label1);		
		JLabel label2 = new JLabel("�� ��");
		panel5.add(label2);
		JLabel label3 = new JLabel("�� ��");
		panel5.add(label3);
		JLabel label4 = new JLabel("����ó");
		panel5.add(label4);
		panel2.add(panel5);
		
		JPanel panel6 = new JPanel(); //�Է�ĭ p6
		panel6.setLayout(new BoxLayout(panel6, BoxLayout.Y_AXIS));
		JTextField t1 = new JTextField(15);
		t1.setEditable(true);
		JTextField t2 = new JTextField(15);
		t2.setEditable(true);
		JTextField t3 = new JTextField(15);
		t3.setEditable(true);
		JTextField t4 = new JTextField(15);
		t4.setEditable(true);
		panel6.add(t1);
		panel6.add(t2);
		panel6.add(t3);
		panel6.add(t4);
		panel2.add(panel6);
		
		JPanel panel7 = new JPanel(); //���� p7
		panel2.add(panel7);
		
		
		JPanel panel3; // �ڱ�Ұ�
		panel3 = new JPanel ();
		panel3.setLayout(new BoxLayout(panel3, BoxLayout.Y_AXIS));
		JLabel label5 = new JLabel("�ڱ�Ұ�");
		panel3.add(label5);
		JTextArea ta = new JTextArea(3,5);  
		panel3.add(ta);
		
				
		JPanel panel4; //�߰� ��� ��ư
		panel4 = new JPanel();
		panel4.setLayout(new FlowLayout(FlowLayout.CENTER)); //panel3
		panel4.add(new JButton("�߰�"));
		panel4.add(new JButton("���"));
		
		add(panel1, BorderLayout.NORTH);
		add(panel2, BorderLayout.WEST);
		add(panel3, BorderLayout.CENTER);
		add(panel4, BorderLayout.SOUTH);
		
		pack();
		setVisible(true);		
	}
	
	public static void main(String[] args) {
		JPanelTest p = new JPanelTest();
	}

}

