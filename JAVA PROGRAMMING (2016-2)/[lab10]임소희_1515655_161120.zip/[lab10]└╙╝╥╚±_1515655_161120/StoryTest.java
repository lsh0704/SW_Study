import javax.swing.*;
import java.awt.*;

class StoryTest extends JFrame {
	StoryTest() {
		
		setPreferredSize(new Dimension(430, 250));
		setSize(430,250);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("SM Story");
		setLayout(null);
		
		JLabel label1 = new JLabel("SM Story");
		add(label1);
		label1.setBounds(20,5,95,30);

		JLabel label2 = new JLabel("������");
		add(label2);
		label2.setBounds(80,45,95,30);
		
		JTextField t = new JTextField(15);
		add(t);
		t.setBounds(150,80,95,30);
		
		JLabel label3 = new JLabel("�̴�");
		add(label3);
		label3.setBounds(270,120,95,30);

		label1.repaint();
		label2.repaint();
		label3.repaint();		
		t.repaint();
		pack();
		setVisible(true);		
	}
	
	public static void main(String[] args) {
		StoryTest s = new StoryTest();
	}

}