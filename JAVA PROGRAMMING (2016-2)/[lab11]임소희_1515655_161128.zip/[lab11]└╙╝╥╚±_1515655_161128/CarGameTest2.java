import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.*;

import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

class CarGame extends JPanel {
	BufferedImage img = null;
	BufferedImage img1 = null;
	BufferedImage img2 = null;
	BufferedImage img3 = null;
	BufferedImage img4 = null;
	int img_x = 170, img_y = 165;
	
	public CarGame () {
		try {
			img = ImageIO.read(new File("��.png"));
			img1 = ImageIO.read(new File("��.png"));
			img2 = ImageIO.read(new File("��.png"));
			img3 = ImageIO.read(new File("��.png"));
			img4 = ImageIO.read(new File("��.png"));
		} catch (IOException e) {
			System.out.println("no image");
			System.exit(1);
		}
		addKeyListener (new KeyListener() {
			public void keyPressed (KeyEvent e) { 
				int keycode = e.getKeyCode();
				switch (keycode) {
				case KeyEvent.VK_UP:	img = img1;	img_y -= 10;	break;
				case KeyEvent.VK_DOWN:	img = img2;	img_y += 10;	break;
				case KeyEvent.VK_LEFT:	img = img3;	img_x -= 10;	break;
				case KeyEvent.VK_RIGHT:	img = img4;	img_x += 10;	break;
				}		
				int width = 425 - img.getWidth();
				int height = 398 - img.getHeight();
				if (img_x>=-8 && img_x <= width && img_y>=-4.5 && img_y <= height) 
						repaint();
				else {
					if (img_x < 0) img_x=0;
					if (img_x > width) img_x=width;
					if (img_y < 0) img_y=0;
					if (img_y > height) img_y=height;
				}
			}
			public void keyReleased (KeyEvent arg0) { }
			public void keyTyped (KeyEvent arg0) {}		
		});
		this.requestFocus();
		setFocusable(true);
	}
	public void paintComponent (Graphics g) {
		super.paintComponent(g);
		g.drawImage(img, img_x, img_y, null);
	}
}
public class CarGameTest2 extends JFrame{
	public CarGameTest2() {
		setSize (445, 453);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		add(new CarGame());
		setVisible(true);
	}
	public static void main(String[] args) {
		CarGameTest2 s = new CarGameTest2();
	}
}
