import java.awt.*;
import javax.swing.*;

class FontPanel extends JPanel {
	protected void paintComponent (Graphics g) {
		super.paintComponent(g);
		Font font = new Font("����鱹ȭ", Font.PLAIN, 36);
		g.setFont(font);
		g.drawString("���� : ���ѹα�", 40, 50);
		Font font2 = new Font("�ü�", Font.ITALIC, 36);
		g.setFont(font2);
		g.drawString("�ּ� : ����� ��걸", 40, 100);
		Font font3 = new Font("�����", Font.ITALIC, 36);
		g.setFont(font3);
		g.drawString("���� : �Ӽ���", 40, 150);
		Font font4 = new Font("HY��������m", Font.BOLD, 36);
		g.setFont(font4);
		g.drawString("�й� : 1515655", 40, 200);
	}
}
class FontTest extends JFrame{
	public FontTest() {
	this.setPreferredSize(new Dimension(500, 300));
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setTitle("Font Test");
	
	add(new FontPanel());	
	pack();
	setVisible(true);
	}
	
	public static void main(String[] args) {
		FontTest f = new FontTest();
	}
}
