import javax.swing.*;
import java.awt.*;

class House extends JPanel {
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.setColor(Color.red); //����
		g.fillRect(350, 100, 30, 80);
		g.setColor(Color.orange); // ����
		int x[] = { 300, 200, 400 }; 
		int y[] = { 100, 200, 200 }; 
		g.fillPolygon( x, y, 3 );
		
		g.setColor(Color.cyan); //����
		g.fillOval(365,50,70,30);
		g.fillOval(380,20,60,20);
	
		g.setColor(Color.black); // ��
		g.fillRect(220, 200,160, 200);
		
		g.setColor(Color.blue); //â��
		g.fillRect(240, 220, 50, 50);
		g.fillRect(310, 220, 50, 50);
		
		g.setColor(Color.magenta); //��
		g.fillRect(260,300,80,100);
		g.setColor(Color.black); //������
		g.fillOval(315,340,15,15);
			
		g.setColor(Color.darkGray); //����
		g.fillRect(80, 260, 40, 140);
		g.fillRect(475, 260, 30, 140);
		g.setColor(Color.green);
		g.fillOval(25,120,150,150);
		g.fillOval(430,160,120,120);
		
		g.setColor(Color.lightGray); //��
		g.fillRect(0,400,600,145);
	}
}
public class HouseTest extends JFrame {
	public HouseTest() {
		this.setPreferredSize(new Dimension(600, 600));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("House Test");
		
		add(new House());	
		pack();
		setVisible(true);
	}
	public static void main(String[] args) {
		HouseTest h = new HouseTest();
	}

}
