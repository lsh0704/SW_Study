import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


class MyFrame extends JFrame implements ActionListener{
	private JButton button;
	private JTextField t1, t2, t3;
	public MyFrame() {
		this.setPreferredSize(new Dimension(370, 190));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("���� ����");
		
		JPanel panel = new JPanel(); 
		panel.setLayout(new BorderLayout());
		
		JPanel panel1 = new JPanel();	
		JPanel panel10 = new JPanel();
		panel10.setLayout(new BoxLayout(panel10, BoxLayout.Y_AXIS));
		JLabel label1 = new JLabel("������ �Է��Ͻÿ�");
		JLabel label2 = new JLabel("������ �Է��Ͻÿ�");
		panel10.add(label1);
		panel10.add(label2);
		panel1.add(panel10);
		
		
		JPanel panel11 = new JPanel();
		panel11.setLayout(new BoxLayout(panel11, BoxLayout.Y_AXIS));
		t1 = new JTextField(13);		
		t2 = new JTextField(13);
		panel11.add(t1);
		panel11.add(t2);
		panel1.add(panel11);
				
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
	
		t3 = new JTextField(30);
		t3.setEditable(false);
		panel3.add(t3);
				
		button = new JButton("��ȯ");
		button.addActionListener(this);
		panel2.add(button);
			
		panel.add(panel1, BorderLayout.NORTH);
		panel.add(panel2, BorderLayout.CENTER);
		panel.add(panel3, BorderLayout.SOUTH);
		add(panel);
		pack();
		setVisible(true);
	}	
	public void actionPerformed(ActionEvent e) {
		int a = Integer.parseInt(t1.getText());
		double b = Double.parseDouble(t2.getText());
		if (e.getSource() == button)		    
			t3.setText("���ڴ� �� "+(int)((a*b)/100)+"�� �Դϴ�.");
		}
}

public class CalcInterest{
	public static void main(String[] args) {
		MyFrame c = new MyFrame();
	}
}

