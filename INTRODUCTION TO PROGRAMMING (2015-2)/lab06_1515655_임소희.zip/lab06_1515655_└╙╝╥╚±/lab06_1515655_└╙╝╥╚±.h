int isort(int v[], int n); /* insertion sort */
int shellsort(int v[], int n); /* Shell sort */
void copyarray(int a[], int b[], int n); /* copy n elements of array b[] to a[] */
void printarray(int a[], int n); /* print n elements of array a[] */
void reverse(char s[]);
void itos(int, char s[], int b);

