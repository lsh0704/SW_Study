int strindex(char s[], int start, char t[]);

#define NUMBER '0'

void push(double);
double pop(void);
int getop(char[]);
int getch(void);
void ungetch(int);

