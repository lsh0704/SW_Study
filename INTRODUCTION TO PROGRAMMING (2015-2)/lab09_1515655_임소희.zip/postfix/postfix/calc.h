#define NUMBER '0'
void push(double);
double pop(void);
int size(void);
int getop(char []);
int getch(void);
void ungetch(int);