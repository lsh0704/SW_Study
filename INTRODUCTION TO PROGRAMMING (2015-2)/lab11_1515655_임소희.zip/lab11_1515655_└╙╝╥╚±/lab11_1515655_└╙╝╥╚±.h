double integ(double(*f)(double), double a, double b, int n)
