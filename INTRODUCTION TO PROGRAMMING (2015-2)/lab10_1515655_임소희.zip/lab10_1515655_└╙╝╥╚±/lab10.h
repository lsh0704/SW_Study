int gethex(int *pn);
void strncat(char *s, int n, const char *t);